import axios from "axios";
const BASE_URL = import.meta.env.VITE_API_URL;
const api = axios.create({
  // 1. Cập nhật baseURL sang cổng 8080 của bạn
  baseURL: BASE_URL,
});

// Interceptor cho Request: Gửi kèm token vào Header
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");

    if (token) {
     
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (res) => res,
  (error) => {
  
    if (error.response?.status === 401) {
   
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      
     
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }

    return Promise.reject(error);
  }
);

export default api;