import React from "react";
import { Layout, Menu } from "antd";
import {
  DashboardOutlined,
  UserOutlined,
  AppstoreOutlined,
  TagsOutlined,
  ShopOutlined,
  ShoppingCartOutlined,
  TagOutlined,
  MessageOutlined,
} from "@ant-design/icons";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import HeaderLayout from "./HeaderLayout";

const { Header, Sider, Content } = Layout;

export default function MainLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  // Danh sách menu bên trái (Sider)
  const menuItems = [
    {
      key: "/",
      icon: <DashboardOutlined />,
      label: "Trang chủ",
    },
    {
      key: "/users",
      icon: <UserOutlined />,
      label: "Người dùng",
    },
    {
      key: "/products",
      icon: <AppstoreOutlined />,
      label: "Sản phẩm",
    },
    {
      key: "/categories",
      icon: <TagsOutlined />,
      label: "Danh mục",
    },
    {
      key: "/suppliers",
      icon: <ShopOutlined />,
      label: "Nhà cung cấp",
    },
    {
      key: "/orders",
      icon: <ShoppingCartOutlined />,
      label: "Đơn hàng",
    },
    {
      key: "/vouchers",
      icon: <TagOutlined />,
      label: "Mã giảm giá",
    },
    {
      key: "/chat",
      icon: <MessageOutlined />,
      label: "Chat",
    },
  ];

  return (
    <div style={{ minHeight: "100vh" }}>
      {/* HeaderLayout này thường chứa các thông tin global như thông báo, profile */}
      <HeaderLayout />

      <Layout>
        {/* Thanh Sidebar cố định bên trái */}
        <Sider
          width={240}
          theme="dark"
          style={{
            height: "100vh",
            position: "fixed",
            left: 0,
            top: 0,
            bottom: 0,
            zIndex: 100, // Đảm bảo Sider luôn nằm trên
          }}
        >
          <div
            style={{
              color: "white",
              fontSize: "18px",
              padding: "20px",
              textAlign: "center",
              fontWeight: 600,
              letterSpacing: "1px",
              borderBottom: "1px solid rgba(255,255,255,0.1)",
              marginBottom: "10px"
            }}
          >
            GreenHealth Admin
          </div>

          <Menu
            theme="dark"
            mode="inline"
            selectedKeys={[location.pathname]}
            onClick={(e) => navigate(e.key)}
            items={menuItems}
          />
        </Sider>

        {/* Vùng nội dung bên phải (đẩy lề trái 240px để không bị Sider đè lên) */}
        <Layout style={{ marginLeft: 240, transition: "all 0.2s" }}>
          <Header
            style={{
              background: "#fff",
              padding: "0 24px",
              height: 64,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
              position: "sticky",
              top: 0,
              zIndex: 99,
            }}
          >
            <div style={{ fontWeight: "bold", fontSize: "16px" }}>
              Xin chào, <span style={{ color: "#1890ff" }}>Admin</span>
            </div>
          </Header>

          <Content
            style={{
              padding: "24px",
              minHeight: "calc(100vh - 64px)",
              background: "#f0f2f5", // Màu nền xám nhẹ đặc trưng của Ant Design
            }}
          >
            <div
              style={{
                background: "#fff",
                padding: "24px",
                borderRadius: "8px",
                minHeight: "100%",
                boxShadow: "0 2px 8px rgba(0,0,0,0.05)"
              }}
            >
              {/* Outlet là nơi hiển thị các Page con như DashboardPage, CategoriesPage... */}
              <Outlet />
            </div>
          </Content>
        </Layout>
      </Layout>
    </div>
  );
}