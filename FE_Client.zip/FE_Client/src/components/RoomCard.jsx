import React, { useState, useEffect } from 'react';
import { MapPin, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function RoomCard({ room }) {
  const navigate = useNavigate();
  const [isFavorited, setIsFavorited] = useState(room.isFavorited);
  const BASE_URL = import.meta.env.VITE_API_URL;

  useEffect(() => {
    setIsFavorited(room.isFavorited);
  }, [room.isFavorited]);

  const handleToggleFavorite = async (e) => {
    e.stopPropagation();
    const token = localStorage.getItem("token");
    if (!token) return alert("Vui lòng đăng nhập!");

    try {
      const res = await fetch(`${BASE_URL}/favorites/toggle`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ roomId: room.id })
      });
      if (res.ok) setIsFavorited(!isFavorited);
    } catch (err) {
      console.error("Lỗi yêu thích:", err);
    }
  };

  const formatPrice = (price) =>
    price ? parseFloat(price).toLocaleString() + " đ" : "-";

  return (
    <div 
      onClick={() => navigate(`/rooms/${room.id}`)}
      className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-lg transition-all cursor-pointer"
    >
      {/* Hình ảnh & nút yêu thích */}
      <div className="relative h-44 overflow-hidden">
        <img 
          src={room.mainImage} 
          alt={room.title}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
        <button 
          onClick={handleToggleFavorite}
          className={`absolute top-3 right-3 p-2 rounded-full shadow-md transition ${
            isFavorited ? 'bg-rose-500 text-white' : 'bg-white/90 text-gray-400 hover:text-rose-500'
          }`}
        >
          <Heart size={16} fill={isFavorited ? "currentColor" : "none"} />
        </button>
        <div className="absolute top-3 left-3 bg-black/50 backdrop-blur px-2 py-1 rounded-md text-white text-[10px] uppercase font-bold">
          {room.type}
        </div>
      </div>

      {/* Nội dung */}
      <div className="p-4 space-y-2">
        <h4 className="text-sm font-bold text-gray-800 line-clamp-2">{room.title}</h4>

        <div className="flex justify-between items-center text-sm font-semibold">
          <span className="text-rose-600">{formatPrice(room.price)}</span>
          <span className="text-gray-500">{room.area} m²</span>
        </div>

        <div className="flex items-center gap-1 text-gray-400 text-[11px] border-t pt-2">
          <MapPin size={12} className="text-blue-500" />
          <span className="truncate">{room.district}, {room.city}</span>
        </div>

        {/* Thông tin chi tiết */}
        <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-600 border-t pt-2">
          <div>Điện: {formatPrice(room.electricPrice)}</div>
          <div>Nước: {formatPrice(room.waterPrice)}</div>
          <div>Internet: {formatPrice(room.internetPrice)}</div>
          <div>Số người tối đa: {room.maxPeople}</div>
          <div className="col-span-2">Đồ nội thất: {room.furniture}</div>
        </div>
      </div>
    </div>
  );
}