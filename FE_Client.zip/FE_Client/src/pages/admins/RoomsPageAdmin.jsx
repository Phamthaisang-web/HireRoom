import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../../services/api"; 
import {
  Modal, Form, Input, InputNumber, Upload, message,
  Table, Button, Select, Popconfirm, Card, Tag
} from "antd";
import { UploadOutlined, HomeOutlined, EnvironmentOutlined } from "@ant-design/icons";

export default function RoomPageAdmin() {
  const queryClient = useQueryClient();
  const [form] = Form.useForm();
  const [open, setOpen] = useState(false);
  const [uploadedImages, setUploadedImages] = useState([]);
  const [editingRoom, setEditingRoom] = useState(null);
  const token = localStorage.getItem("token");

  // --- FIX 1: Đảm bảo trả về mảng ---
  const { data: rooms = [], isLoading } = useQuery({
    queryKey: ["rooms-admin"],
    queryFn: async () => {
      const res = await api.get("/rooms");
      // Nếu API trả về { status, message, data: [...] } thì lấy res.data.data
      // Nếu API trả về mảng trực tiếp thì lấy res.data
      const rawData = res.data;
      return Array.isArray(rawData) ? rawData : (rawData.rooms || rawData.data || []);
    },
  });

  // 2. Mutation: Tạo hoặc Cập nhật phòng
  const upsertRoom = useMutation({
    mutationFn: async (values) => {
      let roomId = editingRoom?.id;

      if (editingRoom) {
        // Update phòng
        await api.put(`/rooms/${editingRoom.id}`, values);
      } else {
        // Tạo phòng mới
        const res = await api.post("/rooms", { ...values, landlordId: 1 });
        roomId = res.data?.roomData?.id;
      }

      // Xử lý upload ảnh mới (nếu có)
      const newImages = uploadedImages.filter(f => f.status === "done" && f.response);
      if (roomId && newImages.length > 0) {
        await Promise.all(
          newImages.map((file) =>
            api.post("/image-rooms", {
              roomId: roomId,
              imageUrl: file.response.url, // Đảm bảo backend trả về { url: "..." }
            })
          )
        );
      }
    },
    onSuccess: () => {
      message.success(editingRoom ? "Cập nhật thành công" : "Thêm phòng thành công");
      handleClose();
      queryClient.invalidateQueries(["rooms-admin"]);
    },
    onError: (err) => message.error(err.response?.data?.message || "Thao tác thất bại"),
  });

  // 3. Mutation: Xóa phòng
  const deleteRoom = useMutation({
    mutationFn: (id) => api.delete(`/rooms/${id}`),
    onSuccess: () => {
      message.success("Đã xóa phòng");
      queryClient.invalidateQueries(["rooms-admin"]);
    },
  });

  const handleClose = () => {
    setOpen(false);
    setEditingRoom(null);
    setUploadedImages([]);
    form.resetFields();
  };

  const columns = [
    {
      title: "Tiêu đề",
      dataIndex: "title",
      key: "title",
      width: 200,
      render: (text) => <b>{text}</b>,
    },
    {
      title: "Giá thuê",
      dataIndex: "price",
      render: (p) => <span style={{ color: "red" }}>{Number(p).toLocaleString()}đ</span>,
    },
    { title: "Diện tích", dataIndex: "area", render: (a) => `${a}m²` },
    { title: "Quận/Huyện", dataIndex: "district" },
    {
      title: "Trạng thái",
      dataIndex: "status",
      render: (s) => <Tag color={s === "còn trống" ? "green" : "red"}>{s}</Tag>,
    },
    {
      title: "Hành động",
      fixed: "right",
      width: 150,
      render: (_, record) => (
        <>
          <Button type="link" onClick={async () => {
             setEditingRoom(record);
             setOpen(true);
             form.setFieldsValue(record);
             
             // Fetch ảnh của phòng này để hiển thị lên Upload list
             try {
               const res = await api.get(`/image-rooms?roomId=${record.id}`);
               const imgs = (res.data.data || res.data).map(img => ({
                 uid: img.id,
                 name: img.imageUrl,
                 status: 'done',
                 url: img.imageUrl.startsWith('http') ? img.imageUrl : `http://localhost:8080${img.imageUrl}`
               }));
               setUploadedImages(imgs);
             } catch (e) { console.log("Chưa có ảnh"); }
          }}>Sửa</Button>
          <Popconfirm title="Xóa?" onConfirm={() => deleteRoom.mutate(record.id)}>
            <Button type="link" danger>Xóa</Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
        <h2><HomeOutlined /> Admin - Quản lý phòng</h2>
        <Button type="primary" onClick={() => setOpen(true)}>+ Thêm phòng</Button>
      </div>

      <Table 
        // --- FIX 2: Ép kiểu mảng an toàn ---
        dataSource={Array.isArray(rooms) ? rooms : []} 
        columns={columns} 
        rowKey="id" 
        loading={isLoading}
        scroll={{ x: 1000 }}
      />

      <Modal
        title={editingRoom ? "Cập nhật" : "Thêm mới"}
        open={open}
        onCancel={handleClose}
        onOk={() => form.submit()}
        confirmLoading={upsertRoom.isPending}
        width={700}
      >
        <Form form={form} layout="vertical" onFinish={(v) => upsertRoom.mutate(v)}>
          <Form.Item label="Hình ảnh">
            <Upload
              action="http://localhost:8080/upload/image"
              headers={{ Authorization: `Bearer ${token}` }}
              listType="picture-card"
              fileList={uploadedImages}
              onChange={({ fileList }) => setUploadedImages(fileList)}
              onRemove={async (file) => {
                if (file.uid && !file.originFileObj) {
                  await api.delete(`/image-rooms/${file.uid}`);
                }
              }}
            >
              {uploadedImages.length < 5 && <UploadOutlined />}
            </Upload>
          </Form.Item>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <Form.Item name="title" label="Tiêu đề" rules={[{ required: true }]}><Input /></Form.Item>
            <Form.Item name="type" label="Loại"><Select options={[{value:'Chung cư', label:'Chung cư'}, {value:'Phòng trọ', label:'Phòng trọ'}]}/></Form.Item>
            <Form.Item name="price" label="Giá thuê"><InputNumber style={{width:'100%'}}/></Form.Item>
            <Form.Item name="area" label="Diện tích"><InputNumber style={{width:'100%'}}/></Form.Item>
            <Form.Item name="city" label="Thành phố"><Input /></Form.Item>
            <Form.Item name="district" label="Quận"><Input /></Form.Item>
          </div>
        </Form>
      </Modal>
    </div>
  );
}