import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Header from '../components/Header'; // Đảm bảo bạn đã import Header
import RoomCard from '../components/RoomCard';
import Slider from 'rc-slider';
import 'rc-slider/assets/index.css';
import { 
  Search, MapPin, Home, Filter, Map, 
  RotateCcw, ChevronUp, ChevronDown,
  ChevronLeft, ChevronRight
} from 'lucide-react';

export default function RoomPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalRooms, setTotalRooms] = useState(0);

  const [isFilterVisible, setIsFilterVisible] = useState(true);
  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [wards, setWards] = useState([]);
  const [localPrice, setLocalPrice] = useState([0, 20000000]);

  const keyword = searchParams.get("keyword") || "";
  const type = searchParams.get("type") || "";
  const city = searchParams.get("city") || "";
  const district = searchParams.get("district") || "";
  const ward = searchParams.get("ward") || "";
  const priceRange = searchParams.get("priceRange") || "0-20000000";
  const page = parseInt(searchParams.get("page") || "1");
  
  const limit = 20;
  const BASE_URL = import.meta.env.VITE_API_URL;

  // 1. Fetch Tỉnh/Thành
  useEffect(() => {
    fetch('https://provinces.open-api.vn/api/?depth=1')
      .then(res => res.json())
      .then(data => setProvinces(data))
      .catch(err => console.error("Lỗi fetch tỉnh:", err));
  }, []);

  // Đồng bộ Slider khi URL thay đổi
  useEffect(() => {
    const [min, max] = priceRange.split("-").map(Number);
    setLocalPrice([min || 0, max || 20000000]);
  }, [priceRange]);

  // 2. Fetch Quận/Huyện & Phường/Xã (Giữ nguyên logic của bạn)
  useEffect(() => {
    if (!city || provinces.length === 0) { setDistricts([]); return; }
    const selected = provinces.find(p => p.name.includes(city));
    if (selected) {
      fetch(`https://provinces.open-api.vn/api/p/${selected.code}?depth=2`)
        .then(res => res.json()).then(data => setDistricts(data.districts));
    }
  }, [city, provinces]);

  useEffect(() => {
    if (!district || districts.length === 0) { setWards([]); return; }
    const selected = districts.find(d => d.name.includes(district));
    if (selected) {
      fetch(`https://provinces.open-api.vn/api/d/${selected.code}?depth=2`)
        .then(res => res.json()).then(data => setWards(data.wards));
    }
  }, [district, districts]);

  const updateFilter = (newFilter) => {
    const currentParams = Object.fromEntries([...searchParams]);
    if (newFilter.city !== undefined && newFilter.city !== currentParams.city) {
      newFilter.district = ""; newFilter.ward = "";
    }
    const updatedParams = { ...currentParams, ...newFilter };
    if (!newFilter.page) updatedParams.page = 1;
    Object.keys(updatedParams).forEach(key => {
      if (!updatedParams[key]) delete updatedParams[key];
    });
    setSearchParams(updatedParams);
  };

  // 3. LOGIC FETCH PHÒNG + ẢNH + FAVORITE (QUAN TRỌNG NHẤT)
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem("token");
        const [minPrice, maxPrice] = priceRange.split("-");
        
        const query = new URLSearchParams({
          page, limit, keyword, type, city, district, ward, minPrice, maxPrice
        }).toString();

        // Gọi API lấy phòng và API yêu thích cùng lúc
        const [roomsRes, favRes] = await Promise.all([
          fetch(`${BASE_URL}/rooms?${query}`),
          token ? fetch(`${BASE_URL}/favorites/me`, { headers: { 'Authorization': `Bearer ${token}` } }) : Promise.resolve(null)
        ]);

        const roomsData = await roomsRes.json();
        const favData = favRes ? await favRes.json() : { rooms: [] };
        
        const rawRooms = roomsData.rooms || [];
        const favIds = (favData.rooms || []).map(r => r.id);
        setTotalRooms(roomsData.pagination?.totalItems || roomsData.total || 0);

        // Gọi API lấy ảnh cho từng phòng (giống HomePage)
        const roomsWithDetails = await Promise.all(
          rawRooms.map(async (room) => {
            const isFavorited = favIds.includes(room.id);
            try {
              const imgRes = await fetch(`${BASE_URL}/image-rooms?roomId=${room.id}`);
              const imgData = await imgRes.json();
              let mainImage = "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1000";
              if (imgData.imageRooms?.length > 0) {
                const url = imgData.imageRooms[0].imageUrl;
                mainImage = url.startsWith('http') ? url : `${BASE_URL}${url}`;
              }
              return { ...room, mainImage, isFavorited };
            } catch {
              return { ...room, mainImage: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1000", isFavorited };
            }
          })
        );

        setRooms(roomsWithDetails);
      } catch (error) {
        console.error("Lỗi fetch:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [keyword, type, city, district, ward, priceRange, page, BASE_URL]);

  const totalPages = Math.ceil(totalRooms / limit);

  return (
    <div className="min-h-screen bg-[#F8F9FA] font-sans text-gray-900">


      {/* Filter Section */}
      <div className="pt-6 pb-6 bg-white border-b border-gray-100 sticky top-0 z-20 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-col gap-5">
            <div className="flex items-end justify-between">
              <div>
                <h1 className="text-xl font-black uppercase tracking-tighter flex items-center gap-2 text-blue-600">
                  <Map size={20} />
                  {district || city || "Khắp Việt Nam"}
                </h1>
                <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest mt-1">
                  Tìm thấy {totalRooms} kết quả
                </p>
              </div>
              
              <div className="flex gap-2">
                <button 
                  onClick={() => setIsFilterVisible(!isFilterVisible)}
                  className="text-[10px] font-black uppercase bg-gray-50 text-gray-500 px-3 py-1.5 rounded-lg hover:bg-gray-100 flex items-center gap-2 transition-all"
                >
                  <Filter size={12} />
                  {isFilterVisible ? "Ẩn lọc" : "Hiện lọc"}
                  {isFilterVisible ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                </button>
                <button 
                  onClick={() => setSearchParams({})} 
                  className="text-[10px] font-black uppercase bg-red-50 text-red-500 px-3 py-1.5 rounded-lg hover:bg-red-100 flex items-center gap-1"
                >
                  <RotateCcw size={12} /> Reset
                </button>
              </div>
            </div>

            {isFilterVisible && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="md:col-span-6 grid grid-cols-3 gap-2">
                  <input list="p-list" value={city} placeholder="Tỉnh/Thành" onChange={(e) => updateFilter({ city: e.target.value })} className="bg-gray-50 rounded-xl px-3 py-3 text-[11px] font-bold outline-none focus:ring-2 focus:ring-blue-500/20" />
                  <datalist id="p-list">{provinces.map(p => <option key={p.code} value={p.name} />)}</datalist>
                  
                  <input list="d-list" disabled={!city} value={district} placeholder="Quận/Huyện" onChange={(e) => updateFilter({ district: e.target.value })} className="bg-gray-50 rounded-xl px-3 py-3 text-[11px] font-bold outline-none focus:ring-2 focus:ring-blue-500/20 disabled:opacity-50" />
                  <datalist id="d-list">{districts.map(d => <option key={d.code} value={d.name} />)}</datalist>
                  
                  <input list="w-list" disabled={!district} value={ward} placeholder="Phường/Xã" onChange={(e) => updateFilter({ ward: e.target.value })} className="bg-gray-50 rounded-xl px-3 py-3 text-[11px] font-bold outline-none focus:ring-2 focus:ring-blue-500/20 disabled:opacity-50" />
                  <datalist id="w-list">{wards.map(w => <option key={w.code} value={w.name} />)}</datalist>
                </div>

                <div className="md:col-span-3">
                  <select value={type} onChange={(e) => updateFilter({ type: e.target.value })} className="w-full bg-gray-50 rounded-xl px-3 py-3 text-[11px] font-bold outline-none">
                    <option value="">Tất cả loại hình</option>
                    <option value="Phòng trọ">Phòng trọ</option>
                    <option value="Chung cư">Chung cư mini</option>
                    <option value="Nhà nguyên căn">Nhà nguyên căn</option>
                  </select>
                </div>

                <div className="md:col-span-3 bg-gray-50 rounded-xl px-4 py-2">
                  <div className="flex justify-between mb-1 text-[9px] font-black text-blue-600">
                    <span>{localPrice[0].toLocaleString()}đ</span>
                    <span>{localPrice[1].toLocaleString()}đ</span>
                  </div>
                  <Slider range min={0} max={20000000} step={500000} value={localPrice} onChange={setLocalPrice} onChangeComplete={(val) => updateFilter({ priceRange: `${val[0]}-${val[1]}` })} trackStyle={[{backgroundColor:'#2563eb'}]} handleStyle={[{borderColor:'#2563eb'},{borderColor:'#2563eb'}]} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-4 py-12">
        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-72 bg-gray-200 rounded-3xl animate-pulse" />
            ))}
          </div>
        ) : rooms.length > 0 ? (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {rooms.map((room) => <RoomCard key={room.id} room={room} />)}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-20 flex justify-center items-center gap-2">
                <button disabled={page === 1} onClick={() => updateFilter({ page: page - 1 })} className="p-2 bg-white border rounded-full disabled:opacity-20 hover:bg-gray-50 transition-all shadow-sm">
                  <ChevronLeft size={18} />
                </button>
                {[...Array(totalPages)].map((_, i) => (
                  <button key={i} onClick={() => updateFilter({ page: i + 1 })} className={`w-10 h-10 rounded-full font-bold text-[11px] transition-all ${page === i + 1 ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-gray-400'}`}>
                    {i + 1}
                  </button>
                ))}
                <button disabled={page === totalPages} onClick={() => updateFilter({ page: page + 1 })} className="p-2 bg-white border rounded-full disabled:opacity-20 hover:bg-gray-50 transition-all shadow-sm">
                  <ChevronRight size={18} />
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-32 bg-white rounded-[3rem] border border-dashed border-gray-200">
            <Search className="text-gray-200 mx-auto mb-4" size={48} />
            <h3 className="font-bold text-gray-900 uppercase">Không tìm thấy kết quả</h3>
            <p className="text-gray-400 text-[11px] mt-1 uppercase font-bold tracking-widest">Hãy thử nới lỏng bộ lọc</p>
          </div>
        )}
      </main>
    </div>
  );
}