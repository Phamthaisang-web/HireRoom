import React, { useState, useEffect } from 'react';
import RoomCard from '../components/RoomCard';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronRight, Search, Calendar, ArrowUpRight, ShieldCheck, Zap, Heart, MapPin } from 'lucide-react';

export default function HomePage() {
  const [rooms, setRooms] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchKeyword, setSearchKeyword] = useState("");
  const BASE_URL = import.meta.env.VITE_API_URL;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem("token");

        // --- Fetch rooms + favorites + events concurrently ---
        const [roomsRes, favRes, eventsRes] = await Promise.all([
          fetch(`${BASE_URL}/rooms?page=1&limit=8`),
          token 
            ? fetch(`${BASE_URL}/favorites/me`, { headers: { Authorization: `Bearer ${token}` } })
            : Promise.resolve(null),
          fetch(`${BASE_URL}/events?limit=3`) // fetch only 3 events
        ]);

        const roomsData = await roomsRes.json();
        const favData = favRes ? await favRes.json() : { rooms: [] };
        const rawRooms = roomsData.rooms || [];
        const myFavIds = (favData.rooms || []).map(r => r.id);

        // --- Fetch room images efficiently ---
        const roomImagesRes = await fetch(`${BASE_URL}/image-rooms?roomIds=${rawRooms.map(r => r.id).join(',')}`);
        const roomImagesData = await roomImagesRes.json();

        const processedRooms = rawRooms.map(room => {
          const isFavorited = myFavIds.includes(room.id);
          let mainImage = "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1000";

          const roomImgs = roomImagesData.imageRooms?.filter(img => img.roomId === room.id);
          if (roomImgs && roomImgs.length > 0) {
            const url = roomImgs[0].imageUrl;
            mainImage = url.startsWith('http') ? url : `${BASE_URL}${url}`;
          }

          return { ...room, mainImage, isFavorited };
        });

        setRooms(processedRooms);

        // --- Set events safely ---
        const eventsData = await eventsRes.json();
        setEvents((eventsData.data || []).slice(0, 3).map(event => ({
          id: event.id,
          title: event.title || "Chưa có tiêu đề",
          image: event.image || "https://via.placeholder.com/400",
          status: event.status || "Chưa có trạng thái",
          startDate: event.startDate || new Date().toISOString(),
          location: event.location || "Đang cập nhật"
        })));

      } catch (err) {
        console.error("Lỗi fetch dữ liệu:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [BASE_URL]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchKeyword.trim()) navigate(`/rooms?keyword=${encodeURIComponent(searchKeyword)}`);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-gray-900">

      {/* Hero Section */}
      <section className="relative w-full h-screen flex items-center justify-center">
        <img 
          src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=2000" 
          className="absolute inset-0 w-full h-full object-cover brightness-50"
          alt="Hero"
        />
        <div className="relative z-10 w-full max-w-xl px-6">
          <h1 className="text-white text-4xl font-black uppercase text-center mb-8">Tìm phòng trọ ưng ý</h1>
          <form onSubmit={handleSearch} className="bg-white p-1 rounded-full flex shadow-2xl">
            <input 
              type="text" 
              className="flex-1 px-6 outline-none text-sm" 
              placeholder="Nhập khu vực cần tìm..." 
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
            />
            <button className="bg-red-500 text-white p-3 rounded-full hover:bg-red-600 transition-all">
              <Search size={20} />
            </button>
          </form>
        </div>
      </section>

      <main className="max-w-6xl mx-auto px-4 py-20">
        {/* Latest Rooms */}
        <div className="flex justify-between items-end mb-10">
          <h3 className="text-2xl font-black uppercase tracking-tighter">Phòng mới nhất</h3>
          <Link to="/rooms" className="text-xs font-bold text-blue-600 uppercase flex items-center gap-1">
            Xem tất cả <ChevronRight size={14} />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map(i => <div key={i} className="h-72 bg-gray-200 animate-pulse rounded-2xl" />)}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {rooms.map(room => <RoomCard key={room.id} room={room} />)}
          </div>
        )}

        {/* FEATURES Section */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 text-center px-4 py-10">
          {[{
            icon: ShieldCheck,
            title: "Thông tin xác thực",
            text: "Mọi bài đăng đều được kiểm duyệt hình ảnh và thông tin pháp lý nghiêm ngặt.",
            color: "blue"
          },{
            icon: Zap,
            title: "Thuê phòng nhanh",
            text: "Quy trình đặt lịch xem phòng trực tuyến đơn giản chỉ với vài lần nhấp chuột.",
            color: "green"
          },{
            icon: Heart,
            title: "Cộng đồng văn minh",
            text: "Hệ thống đánh giá cư dân giúp bạn tìm thấy những người bạn cùng nhà tuyệt vời.",
            color: "red"
          }].map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="flex flex-col items-center group">
                <div className={`w-12 h-12 md:w-16 md:h-16 bg-${item.color}-50 text-${item.color}-600 rounded-xl md:rounded-2xl flex items-center justify-center mb-3 md:mb-4 shadow-sm transition-all group-hover:bg-${item.color}-600 group-hover:text-white`}>
                  <Icon size={24} className="md:w-8 md:h-8" />
                </div>
                <div className="max-w-[280px] md:max-w-none">
                  <h4 className="text-base md:text-1xl font-black uppercase tracking-tight text-gray-800">{item.title}</h4>
                  <p className="text-gray-400 text-xs md:text-sm leading-relaxed mt-2 px-2">{item.text}</p>
                </div>
              </div>
            );
          })}
        </section>

        {/* LOCATIONS Section */}
        <section>
          <div className="text-center mb-16">
            <h2 className="text-[10px] font-black text-blue-600 uppercase tracking-[0.4em] mb-3">Thuê phòng</h2>
            <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">Khám phá phòng trọ theo khu vực và khoảng cách bạn muốn</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: "Quận 1", img: "https://images.unsplash.com/photo-1583417319070-4a69db38a482?q=80&w=400", count: "120+ phòng" },
              { name: "Bình Thạnh", img: "https://images.unsplash.com/photo-1555620986-044735073676?q=80&w=400", count: "85+ phòng" },
              { name: "Quận 7", img: "https://images.unsplash.com/photo-1549439602-43ebca2327af?q=80&w=400", count: "60+ phòng" },
              { name: "Quận 9", img: "https://images.unsplash.com/photo-1590001158193-790179980bd3?q=80&w=400", count: "45+ phòng" },
            ].map((loc, i) => (
              <Link to={`/rooms?keyword=${loc.name}`} key={i} className="group relative h-64 rounded-3xl overflow-hidden">
                <img src={loc.img} className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={loc.name} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6">
                  <h4 className="text-white font-black uppercase text-lg">{loc.name}</h4>
                  <p className="text-white/60 text-[10px] font-bold uppercase tracking-widest">{loc.count}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* EVENTS Section */}
      <section className="bg-white p-8 rounded-2xl shadow-sm mt-20">
  <div className="flex justify-between items-center mb-8">
    <div>
      <h3 className="text-xl font-bold uppercase tracking-tight">Hoạt động sắp tới</h3>
      <p className="text-gray-500 text-sm">Không chỉ là nơi ở, chúng tôi xây dựng một lối sống gắn kết.</p>
    </div>
    <Link to="/events" className="text-blue-600 font-bold uppercase text-sm flex items-center gap-1">
      Xem tất cả <ArrowUpRight size={16} />
    </Link>
  </div>

  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
    {loading
      ? [1,2,3].map(i => <div key={i} className="h-48 bg-gray-200 animate-pulse rounded-lg" />)
      : events.slice(0,3).map(event => (
          <Link to={`/events/${event.id}`} key={event.id} className="block group">
            <img src={event.image} alt={event.title} className="w-full h-40 object-cover rounded-lg mb-2" />
            <div className="text-xs text-blue-600 uppercase font-bold mb-1">{new Date(event.startDate).toLocaleDateString('vi-VN')}</div>
            <h4 className="font-bold text-gray-900 mb-1 truncate">{event.title}</h4>
            <div className="text-gray-400 text-xs flex items-center gap-1">
              <MapPin size={12} /> {event.location}
            </div>
          </Link>
      ))
    }
  </div>
</section>

      </main>
    </div>
  );
}