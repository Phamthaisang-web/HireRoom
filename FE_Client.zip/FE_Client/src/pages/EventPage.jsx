import React, { useState, useEffect } from 'react';
import { Calendar, MapPin, ArrowUpRight, Clock } from 'lucide-react';
import Header from '../components/Header';

export default function EventsPage() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
const BASE_URL = import.meta.env.VITE_API_URL;
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch(`${BASE_URL}/events`);
        const json = await res.json();
        // Cấu trúc API của bạn: { status: 200, data: [...] }
        setEvents(json.data || []);
      } catch (err) {
        console.error("Lỗi kết nối API:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchEvents();
  }, []);

  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 selection:bg-blue-100">
      

      {/* Hero Section - Typography cực đại, tối giản chi tiết */}
      <header className="pt-40 pb-20 px-6 border-b border-gray-50">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-8 h-[2px] bg-blue-600"></span>
            <span className="text-[10px] font-black tracking-[0.4em] text-blue-600 uppercase">
              Exclusive Events 2026
            </span>
          </div>
          <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter leading-[0.85] mb-8">
            Kết nối <br />
            <span className="text-gray-200">Cộng đồng</span>
          </h1>
          <p className="max-w-md text-gray-400 text-sm font-medium leading-relaxed">
            Hệ thống sự kiện dành riêng cho cư dân và đối tác, nơi chia sẻ kiến thức và cơ hội hợp tác mới.
          </p>
        </div>
      </header>

     {/* Events */}
      <main className="max-w-4xl mx-auto px-6 py-12 space-y-12">
        {loading ? (
          <div className="space-y-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-48 bg-gray-100 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : events.length > 0 ? (
          events.map(event => (
            <article key={event.id} className="flex flex-col md:flex-row gap-6 items-start">
              <img 
                src={event.image || "https://via.placeholder.com/400"} 
                alt={event.title} 
                className="w-full md:w-64 h-40 object-cover rounded-xl"
              />
              <div className="flex-1 flex flex-col justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-3 text-xs text-gray-400 uppercase">
                    <div className="flex items-center gap-1"><Calendar size={14} /> {new Date(event.startDate).toLocaleDateString('vi-VN')}</div>
                    <div className="flex items-center gap-1"><Clock size={14} /> {new Date(event.startDate).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })}</div>
                  </div>
                  <h2 className="text-lg font-bold uppercase">{event.title}</h2>
                  <p className="text-gray-500 text-sm line-clamp-2">{event.description}</p>
                </div>
                <div className="flex justify-between items-center mt-2 text-xs text-gray-400 uppercase">
                  <div className="flex items-center gap-1"><MapPin size={12} /> {event.location}</div>
                  <ArrowUpRight size={16} className="text-blue-500" />
                </div>
              </div>
            </article>
          ))
        ) : (
          <p className="text-center text-gray-300 uppercase text-xs">No events found</p>
        )}
      </main>

      
    </div>
  );
}